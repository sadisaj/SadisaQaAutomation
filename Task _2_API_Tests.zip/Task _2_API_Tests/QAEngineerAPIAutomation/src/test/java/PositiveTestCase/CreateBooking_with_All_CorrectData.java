package PositiveTestCase;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;

public class CreateBooking_with_All_CorrectData {
	
  @Test
  public void createBooking() {
	  
	  HashMap dataset1 = new HashMap();
	  dataset1.put("firstname", "Jim"); 
	  dataset1.put("lastname", "Brown");
	  dataset1.put("totalprice", 111);
	  dataset1.put("depositpaid", true); 
	  
	  HashMap dataset2 = new HashMap();
	  dataset2.put("checkin", "2018-01-01");
	  dataset2.put("checkout", "2019-01-01");
	  
	  dataset1.put("bookingdates", dataset2);
	  
	  dataset1.put("additionalneeds", "Breakfast");	
	  	  
	  given()
	  	.baseUri("https://restful-booker.herokuapp.com/booking")
	  	.contentType(ContentType.JSON)
	  	.body(dataset1)
	  	.log()
		.all()
	  	
	  .when()
	  	.post()
	  
	  .then()
		.assertThat()
		.log()
		.all()
		.statusCode(200)
		.body("booking.firstname", equalTo("Jim"))
		.body("booking.lastname", equalTo("Brown"))
		.body("booking.totalprice", equalTo(111))
		.body("booking.depositpaid", equalTo(true))
		.body("booking.bookingdates.checkin", equalTo("2018-01-01"))
		.body("booking.bookingdates.checkout", equalTo("2019-01-01"))
		.body("booking.additionalneeds", equalTo("Breakfast"));
  
  }

}
