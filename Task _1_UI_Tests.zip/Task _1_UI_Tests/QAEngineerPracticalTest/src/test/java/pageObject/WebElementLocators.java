package pageObject;

import java.awt.Desktop.Action;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class WebElementLocators {
	
	WebDriver driverOne;
	
	public WebElementLocators(WebDriver driverTwo) {
		driverOne = driverTwo;
		PageFactory.initElements(driverTwo, this);
	}
	
	@FindBy(id = "search")
	@CacheLookup
	public WebElement searchItem;
	
	@FindBy(xpath = "//button[@title='Search']")
	@CacheLookup
	public WebElement ClickOnsearch;
	
	@FindBy(xpath = "//span[@class='base']")
	@CacheLookup
	public WebElement searchedElement;
	
	@FindBy(xpath = "//span[text()='Women']")
	@CacheLookup
	public WebElement ElementWomen;
	
	public void MouseHoverOnWomen() throws InterruptedException {
		
		Actions action = new Actions(driverOne);
        action.moveToElement(ElementWomen).perform();
        Thread.sleep(2000);
	}
	
	@FindBy(xpath = "//span[text()='Tops']")
	@CacheLookup
	public WebElement ElementTops;
	
	@FindBy(xpath = "//div[text()='Category']")
	@CacheLookup
	public WebElement ElementCategory;
	
	@FindBy(xpath = "//div[text()='Category']/../div[2]/ol/li[3]/a")
	@CacheLookup
	public WebElement ElementCategoryItems;
	
	@FindBy(xpath = "//strong[text()='Now Shopping by']")
	@CacheLookup
	public WebElement ElementToScroll;
	
	@FindBy(xpath = "//div[text()='Color']")
	@CacheLookup
	public WebElement ElementCickColor;
	
	@FindBy(xpath = "//div[text()='Color']/../div[2]/div/div/a[7]/div")
	@CacheLookup
	public WebElement ElementCickRedColor;
	
	@FindBy(xpath = "//strong[text()='Now Shopping by']/../ol/li/span[text()='Category']/following-sibling::span")
	@CacheLookup
	public WebElement ElementCategoryget;
	
	@FindBy(xpath = "//strong[text()='Now Shopping by']/../ol/li/span[text()='Color']/following-sibling::span")
	@CacheLookup
	public WebElement ElementColorget;
	
	@FindBy(xpath = "//span[text()='Gear']")
	@CacheLookup
	public WebElement ElementGear;
	
	public void MouseHoverOnGear() throws InterruptedException {
		
		Actions action = new Actions(driverOne);
        action.moveToElement(ElementGear).perform();
        Thread.sleep(2000);
	}
	
	@FindBy(xpath = "//span[text()='Watches']")
	@CacheLookup
	public WebElement ElementSelectWatches;
	
	@FindBy(xpath = "//strong[text()='Compare Products']")
	@CacheLookup
	public WebElement ElementToScrollinWatches;
	
	@FindBy(xpath = "(//span[text()='Watches'])[2]/../../following-sibling::div[2]/div/div[3]/ol/li[5]/div/div/strong/a")
	@CacheLookup
	public WebElement ElementClickOnSelectedWatch;
	
	@FindBy(xpath = "//span[text()='Dash Digital Watch']")
	@CacheLookup
	public WebElement ElementGetWatchname;
	
	@FindBy(xpath = "//span[text()='Qty']/../following-sibling::div/input")
	@CacheLookup
	public WebElement ElementGetQuantity;
	
	@FindBy(xpath = "//span[text()='Dash Digital Watch']/../../../div[3]/div/span/span/span")
	@CacheLookup
	public WebElement ElementGetPrice;
	
	@FindBy(xpath = "//button[@id='product-addtocart-button']")
	@CacheLookup
	public WebElement ClickOnAddToCart;
	
	@FindBy(xpath = "//div[@data-bind='html: $parent.prepareMessageForHtml(message.text)']")
	@CacheLookup
	public WebElement SuccessMsg;
	
	@FindBy(xpath = "//span[@class='counter-number']")
	@CacheLookup
	public WebElement clickoncartNumber;
	
	@FindBy(xpath = "//a[text()='Dash Digital Watch']")
	@CacheLookup
	public WebElement ElementGetWatchnameAfterAdding;
	
	@FindBy(xpath = "//label[text()='Qty']/../input")
	@CacheLookup
	public WebElement ElementGetQuantityAfterAdding;
	
	@FindBy(xpath = "//a[text()='Dash Digital Watch']/../../div/div/span/span/span/span")
	@CacheLookup
	public WebElement ElementGetPriceAfterAdding;
	
	@FindBy(xpath = "//button[@id='btn-minicart-close']")
	@CacheLookup
	public WebElement close;
	
}
