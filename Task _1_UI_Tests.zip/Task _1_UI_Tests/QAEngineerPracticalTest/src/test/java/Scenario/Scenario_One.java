package Scenario;

import org.testng.annotations.Test;

import BaseClass.BaseClass;
import pageObject.WebElementLocators;

public class Scenario_One extends BaseClass{
	
	
  @Test
  public void SearchItem() {
	  
	  WebElementLocators practicaltest = new WebElementLocators(driver);
	  
	  
	  practicaltest.searchItem.sendKeys("Bags for women");
	  practicaltest.ClickOnsearch.click();
	  
	  String Actualresults = practicaltest.searchedElement.getText().toString(); 
	  String Expectedresults = "Search results for: 'Bags for women'";
	  
	  if(Actualresults.equals(Expectedresults)) {
		  
		  System.out.println("Successfully matched the search term");
		  
	  }else {
		  
		  System.out.println("Search term is not matched");
		  
	  }
	  
  }
}
