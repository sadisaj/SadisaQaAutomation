package Scenario;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import BaseClass.BaseClass;
import pageObject.WebElementLocators;

public class Scenario_Three extends BaseClass{
	
	
  @Test
  public void AddTocart() throws InterruptedException {
	  
	  WebElementLocators practicaltest = new WebElementLocators(driver);
	  
	  practicaltest.MouseHoverOnGear();
	  practicaltest.ElementSelectWatches.click();
	  
	  WebElement element = practicaltest.ElementToScrollinWatches;
	  JavascriptExecutor js = (JavascriptExecutor) driver;
	  js.executeScript("arguments[0].scrollIntoView(true);", element);
	  Thread.sleep(500);
	  
	  practicaltest.ElementClickOnSelectedWatch.click();
	  
	  String Watchname = practicaltest.ElementGetWatchname.getText().toString();
	  String WatchQty = practicaltest.ElementGetQuantity.getAttribute("value");
	  String WatchPrice = practicaltest.ElementGetPrice.getText().toString();
	  
	  practicaltest.ClickOnAddToCart.click();
	  Thread.sleep(5000);
	  
	  String ActualsuccessMsg = practicaltest.SuccessMsg.getText().toString();
	  String ExpectedsuccessMsg = "You added "+Watchname+" to your shopping cart.";
	  
	  if(ActualsuccessMsg.equals(ExpectedsuccessMsg)) {
		  
		  System.out.println("Successfully Add to cart, watch : "+Watchname);
		  
	  }else {
		  
		  System.out.println("You can't Add to Cart, watch : "+Watchname);
		  
	  }
	  
	  practicaltest.clickoncartNumber.click();
	  Thread.sleep(3000);
	  
	  String WatchnameAfterAdding = practicaltest.ElementGetWatchnameAfterAdding.getText().toString();
	  String WatchQtyAfterAdding = practicaltest.ElementGetQuantityAfterAdding.getAttribute("data-item-qty");
	  String WatchPriceAfterAdding = practicaltest.ElementGetPriceAfterAdding.getText().toString();
	  
	  if(Watchname.equals(WatchnameAfterAdding)) {
		  
		  System.out.println("Watch Name Successfully verified : "+Watchname);
		  
	  }else {
		  
		  System.out.println("Watch Name not verified : ");
		  
	  }
	  
	  if(WatchQty.equals(WatchQtyAfterAdding)) {
		  
		  System.out.println("Watch qty Successfully verified : "+WatchQty);
		  
	  }else {
		  
		  System.out.println("Watch qty not verified : ");
		  
	  }
	  
	  if(WatchPrice.equals(WatchPriceAfterAdding)) {
		  
		  System.out.println("Watch price Successfully verified : "+WatchPrice);
		  
	  }else {
		  
		  System.out.println("Watch price not verified : ");
		  
	  }
	  
	  practicaltest.close.click();
	  
	  
  }
}
