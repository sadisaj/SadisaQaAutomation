package Scenario;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import BaseClass.BaseClass;
import pageObject.WebElementLocators;

public class Scenario_Two extends BaseClass{
	
	
  @Test
  public void SearchItemUnderWomenTops() throws InterruptedException {
	  
	  WebElementLocators practicaltest = new WebElementLocators(driver);
	  
	  practicaltest.MouseHoverOnWomen();
	  practicaltest.ElementTops.click();
	  
	  practicaltest.ElementCategory.click();
	  String SelectedCatotegoryBeforeSplit = practicaltest.ElementCategoryItems.getText().toString();
	  String[] SelectedCatotegoryArray = SelectedCatotegoryBeforeSplit.split(" ");
	  String SelectedCatotegory = SelectedCatotegoryArray[0];
	  practicaltest.ElementCategoryItems.click();
	  System.out.println("Selected Catrgory : "+SelectedCatotegory);
	  
	  WebElement element = practicaltest.ElementToScroll;
	  JavascriptExecutor js = (JavascriptExecutor) driver;
	  js.executeScript("arguments[0].scrollIntoView(true);", element);
	  Thread.sleep(500);
	  
	  practicaltest.ElementCickColor.click();
	  String SelectedColor = practicaltest.ElementCickRedColor.getAttribute("option-label");
	  practicaltest.ElementCickRedColor.click();
	  System.out.println("Selected Color : "+SelectedColor);
	  
	  String ActualCategory = practicaltest.ElementCategoryget.getText().toString();
	  String ExpectedCatogory = SelectedCatotegory;
	  
	  if(ActualCategory.equals(ExpectedCatogory)) {
		  
		  System.out.println("Selected Category matched");
		  
	  }else {
		  
		  System.out.println("Selected Category not matched");
		  
	  }
	  
	  String ActualColor = practicaltest.ElementColorget.getText().toString();
	  String ExpectedColor = SelectedColor;
	  
	  if(ActualColor.equals(ExpectedColor)) {
		  
		  System.out.println("Selected Color matched");
		  
	  }else {
		  
		  System.out.println("Selected Color not matched");
		  
	  }
	  
  }
}
