package BaseClass;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass {

	public static WebDriver driver;
	
	@BeforeClass
	public void OpenBrowser() {
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();		
		driver.manage().window().maximize();
		driver.get("https://magento.softwaretestingboard.com/");
		
	}
	
	@AfterClass
	public void CloseBrowser() throws InterruptedException
	{  
		Thread.sleep(3000);
		driver.close();
		driver.quit();
	}
	
}
